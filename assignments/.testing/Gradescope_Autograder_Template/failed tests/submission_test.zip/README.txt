Hidden testing assignment.
Adds dependency checks and compression round-trip tests.
